<?php
// Protect from unauthorized access
defined('_JEXEC') or die;

define('ADMINTOOLS_VERSION', '3.4.4');
define('ADMINTOOLS_DATE', '2015-02-16');
define('ADMINTOOLS_PRO','0');