<?php

/**
 * @version		1.0.0
 * @package		konsa_expeditions
 * @copyright	2010 SP
 * @license		GPLv2
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class ElementController extends JController{

	function display()
	{
		parent::display();
	}
}

class TownsController extends JController{

	function display()
	{
		parent::display();
	}
}

class ExpeditionsController extends JController{

	function display()
	{
		parent::display();
	}
}

class ArtistsController extends JController{

	function display()
	{
		parent::display();
	}
}

class CollectorsController extends JController{

	function display()
	{
		parent::display();
	}
}

class SongsController extends JController{

	function display()
	{
		parent::display();
	}
}
class TracksController extends JController{

	function display()
	{
		parent::display();
	}
}

class PhonogramsController extends JController{

	function display()
	{
		parent::display();
	}
}

class RegionsController extends JController{

	function display()
	{
		parent::display();
	}
}

class CpanelController extends JController{

	function display()
	{
		parent::display();
	}
}

class DocumentsController extends JController{

	function display()
	{
		parent::display();
	}
}

class PhotosController extends JController{

	function display()
	{
		parent::display();
	}
}

class SessionsController extends JController{

	function display()
	{
		//require_once JPATH_COMPONENT.'/helpers/helpers.php';
		parent::display();
	}
}
