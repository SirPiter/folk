AudioPlayer.setup("http://folklab.ru/administrator/components/com_konsaexp/assets/audio-player/player.swf", {  
                width: 200  
            });