<?php


/** 
 * @version		1.5.0
 * @package		konsaexp
 * @copyright	
 * @license		GPLv2
 */
jimport('joomla.application.component.controller');

class ExpeditionsController extends JController
{

	function display()
	{
		parent::display();
	}
}
class CollectorsController extends JController
{

	function display()
	{
		parent::display();
	}
	function search_albums(){
		parent::display();
	}
	
}

class ExpeditionController extends JController
{

	function display()
	{
		parent::display();
	}
}


class PhonogramsController extends JController
{
	function display()
	{
		parent::display();
	}
}


?>
