<?php

/**
 * @version		1.0.0
 * @package		konsa_expeditions
 * @copyright	2010 SP
 * @license		GPLv2
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class PhonogramsControllerPhonograms extends PhonogramsController
{

	function __construct()
	{
		parent::__construct();

	}

}
