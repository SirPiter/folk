<?php

/**
 * @version		2.5.4
 * @package		konsaexp
 * @copyright	2014 sirpiter.ru
 * @license		GPLv2
 */


// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class PhotosControllerPhotos extends PhotosController
{

	function __construct()
	{
		parent::__construct();

	}

}