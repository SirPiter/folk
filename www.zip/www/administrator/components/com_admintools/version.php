<?php
// Protect from unauthorized access
defined('_JEXEC') or die;

define('ADMINTOOLS_VERSION', '3.4.3');
define('ADMINTOOLS_DATE', '2015-01-11');
define('ADMINTOOLS_PRO','0');