<?php
defined('_JEXEC') or die();
define('AKEEBA_LASTVERSIONCHECK','4.1.1');