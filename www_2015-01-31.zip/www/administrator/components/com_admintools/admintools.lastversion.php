<?php
defined('_JEXEC') or die;
define('ADMINTOOLS_LASTVERSIONCHECK','3.4.3');