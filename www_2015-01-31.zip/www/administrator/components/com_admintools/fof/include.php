<?php
defined('_JEXEC') or die();

if (!defined('F0F_INCLUDED'))
{
	include_once JPATH_LIBRARIES . '/f0f/include.php';
	// Do not remove this line - for some reason, PHP 5.4.1 didn't load this file if I removed this line.
}